package com.parkpie.backend.admin.controller;

import com.parkpie.backend.admin.service.AdminDatabaseService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admin")
public class AdminDbController {

    private final AdminDatabaseService db;

    public AdminDbController(AdminDatabaseService db) {
        this.db = db;
    }

    @GetMapping("/db-info")
    public ResponseEntity<?> dbInfo() {
        return ResponseEntity.ok(db.fetchDbInfo());
    }
}
